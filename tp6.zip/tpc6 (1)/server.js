var http =  require('http')
var url  =  require('url')
var pug = require('pug')
var fs = require('fs')
var jsonfile = require('jsonfile')
var {parse} = require('querystring')
var myBD = 'todo.json' 

var myServer = http.createServer((req,res)=>{
    var purl= url.parse(req.url,true)
    var query = purl.query
    
    console.log('Recebi o pedido: '+ purl.pathname)
    console.log('Com o metodo: ' + req.method)

    if(req.method=='GET') {

        if(purl.pathname == '/') {
            jsonfile.readFile(myBD,(erro,todos)=>{
                if (!erro) {
                    res.writeHead(200,{'Content-Type': 'text/html'})
                    res.write(pug.renderFile('pug/index.pug',{todo:todos}))
                    res.end()
                }
                else {
                    res.writeHead(200,{'Content-Type': 'text/html'})
                    res.write(pug.renderFile('pug/erro.pug',{e:"Erro na leitura da BD!"}))
                    res.end()
                }
            })
        }

        else if(purl.pathname =='/w3.css'){
            res.writeHead(200,{'Content-Type': 'text/css'})
            fs.readFile('stylesheet/w3.css', (erro,dados)=>{
                if(!erro) {
                    res.write(dados)
                }
                else {
                    res.write(pug.renderFile('pug/erro.pug',{e:erro}))
                }
                res.end()
            })
            
        }
        else {
            res.writeHead(200,{'Content-Type': 'text/html'})
            res.write(pug.renderFile('pug/erro.pug',{e:"Erro: " + purl.pathname + " Página não encontrada!"}))
            res.end()
        }

    }else if (req.method=='POST') {

        if(purl.pathname=='/processaForm') {
            recuperaInfo(req,(resultado) =>{
                jsonfile.readFile(myBD,(erro,alunos)=>{

                    if(!erro){
                        console.log('Tam: ' + alunos.length)
                        var tam=1
                        if (alunos.length > 0){
                            console.log('Entrei')
                            var x = alunos[alunos.length-1].id
                            console.log('Ultimo '+ x)
                            tam= parseInt(x, 10)
                            tam=tam+1
                            console.log('tamanho aumentado' + tam)
                        }

                        //ADD o campo eliminado
                        // var obj = JSON.parse(resultado);
                        resultado['id']=  tam.toString()
                        resultado['eliminado']='nao'
                        res=JSON.stringify(resultado);
                        console.log('OBTIDO' + res)
                        //ADD o campo eliminado
                        alunos.push(resultado)
                        console.dir(alunos)
                        jsonfile.writeFile(myBD,alunos,erro=>{
                            if(erro) console.log(erro)
                            else console.log('Registo gravado com sucesso!')
                        })
                    }
                })
                
                res.writeHead(301,{Location: 'http://localhost:4007/'});
                res.end()
            })
        }else if(purl.pathname=='/apagaForm') {
            recuperaInfo(req,(apagado) =>{
                console.log(JSON.stringify(apagado))
                var id= apagado['selecao']
                jsonfile.readFile(myBD,(erro,tarefas)=>{

                    if(!erro){
                        for (var j = 0; j < tarefas.length; j++){
                            if(tarefas[j].id==id) {
                                tarefas[j].eliminado='sim'
                                console.log(JSON.stringify(tarefas[j]))
                            }
                        }
                        jsonfile.writeFile(myBD,tarefas,erro=>{
                            if(erro) console.log(erro)
                            else console.log('Registo atualizado com sucesso!')
                        })   
                    }
                    res.writeHead(301,{Location: 'http://localhost:4007/'});
                    res.end()
            })
        })
        } else {
            res.writeHead(200,{'Content-Type': 'text/html'})
            res.write(pug.renderFile('pug/erro.pug',{e:"Erro: " + purl.pathname + " Página não encontrada!"}))
            res.end()
        }

    }
    else{
        res.writeHead(200,{'Content-Type': 'text/html'})
        res.write(pug.renderFile('pug/erro.pug',{e:"Metodo: " + req.method + " Nao suportado!"}))
        res.end()
    }
})

myServer.listen(4007,()=>{
    console.log('Servidor a escuta na porta 4007')
})

function recuperaInfo(request,callback){
    if(request.headers['content-type']=== 'application/x-www-form-urlencoded') {
        let body =''
        request.on('data',bloco=>{
            body += bloco.toString()
        })
        request.on('end',()=>{
            callback(parse(body))
        })
    } else callback(null)
}
