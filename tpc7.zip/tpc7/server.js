var express = require('express')
var jsonfile = require('jsonfile')
var http = require('http')
var fs =   require('fs')
var formidable = require('formidable')
var logger = require('morgan')
var pug = require('pug')
var app = express()
var path = require('path');
var myBD='catalogo.json'
app.use(logger('combined'))

app.get('/',(req,res)=>{
    jsonfile.readFile(myBD,(erro,todos)=>{
        if (!erro) {
            res.write(pug.renderFile('./pug/index.pug',{catalogo:todos}))
            res.end()
        }else {
            res.writeHead(200,{'Content-Type': 'text/html'})
            res.write(pug.renderFile('./pug/erro.pug',{e:"Erro na leitura da BD!"}))
            res.end()
        }
    })
})
app.get('/w3.css',(req,res)=>{
    res.writeHead(200,{'Content-Type': 'text/css'})
    fs.readFile('stylesheet/w3.css', (erro,dados)=>{
        if(!erro) {
            res.write(dados)
        }
        else {
            res.write(pug.renderFile('/pug/erro.pug',{e:erro}))
            res.end()
        }
        res.end()
    })
})
app.post('/processaForm',(req,res)=>{
    var form = new formidable.IncomingForm()
    form.parse(req,(erro,fields,files)=>{

        
            var fenviado = files.ficheiro.path
            var fnovo= './uploaded/' + files.ficheiro.name
            fs.rename(fenviado,fnovo,function(err){
                if (!err) {

                    
                    jsonfile.readFile(myBD,(erro,catalogo)=>{
                        data = Date(Date.now()).toString()
                        res= data.split('(')
                        if(!erro){

                            var data = {
                                id: catalogo.length,
                                name: files.ficheiro.name,
                                desc: fields.desc,
                                data: res[0]
                            };
                            catalogo.push(data)
                            jsonfile.writeFile(myBD,catalogo,erro=>{
                                if(erro) console.log(erro)

                                else {
                                    console.log('Registo gravado com sucesso!')
                                }
                            })

                        } else {
                            console.log('Erro no ficheiro ' + erro)
                        }
                    })

                res.writeHead(301,{Location: 'http://localhost:4007/'});
                res.end()
                }else {
                    res.write(pug.renderFile('/pug/erro.pug',{e:'Ocorreram erros na gravação do ficheiro!'}))
                    res.end()
                }

            })
        })
      
})


app.get('/ficheiros/:nome',(req,res)=>{
    res.sendFile(__dirname + '/uploaded/'+req.params.nome)
})




var myServer= http.createServer(app)


myServer.listen(4007,()=>{
    console.log('Servidor a escuta na porta 4007')
})