# especie de selo que garante a integridade da mensagem
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, hmac

###GERAR A KEY A PARTIR DE PASSPHRASE
backend = default_backend()
salt = os.urandom(16)
kdf = PBKDF2HMAC(
    algorithm=hashes.SHA256(),
    length=64,
    salt=salt,
    iterations=100000,
    backend=backend
)   

key = kdf.derive(b"benfica37")
keyMsg = key[:32]
keyMac = key[32:]
#print(bytes("teste",'utf-8') + keyMsg)
## no more key generation
msg="gosto muito de ir as aulas de tc"
nonce = os.urandom(16)
algorithm = algorithms.ChaCha20(keyMsg, nonce)
cipher = Cipher(algorithm, mode=None, backend=default_backend())
encryptor = cipher.encryptor()
ct = encryptor.update(bytes(msg,'utf-8'))
#print(msg)
#print(str(nonce))

##
##decryptor = cipher.decryptor()
#print(decryptor.update(ct))
###################################################################

criptograma= bytes(str(ct)+str(nonce)+str(salt),'utf-8')
#print(b"criptograma: " + criptograma)
cript="ola"
h = hmac.HMAC(keyMac, hashes.SHA256(), backend=default_backend())
h.update(b"message to hash")
st =  h.finalize()

#decifrar
z =  hmac.HMAC(keyMac, hashes.SHA256(), backend=default_backend())
z.update(b"message tsdso hash")
try:
    z.verify(st)
except:
     print("HASH INCORRETA!")

else:
    print("HASH CORRETA!")
