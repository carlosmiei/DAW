from cryptography.fernet import Fernet

file=open("ficheiro.txt","rb")
file2=open("ficheiro.enc","a")
key = Fernet.generate_key()
f = Fernet(key)
token = f.encrypt(file.read())
g= f.decrypt(token)
file2.write(str(token))
