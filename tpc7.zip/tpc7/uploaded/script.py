from cryptography.fernet import Fernet

def cifrar():
    file=open("ficheiro.txt","rb")
    file2=open("ficheiro.enc","wb")
    file3=open("key.txt","wb");
    key = Fernet.generate_key()
    file3.write(key)
    f = Fernet(key)
    token = f.encrypt(file.read())
    file2.write(token)
    file2.close()
    file3.close()

def decifrar():
    file3=open("key.txt","rb")
    file2=open("ficheiro.enc","rb")
    texto=file2.read()
    key =file3.read()
    f = Fernet(key)
    g= f.decrypt(texto)
    print(g)
    file2.close()
    file3.close()

cifrar()
decifrar()
