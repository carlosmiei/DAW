from Crypto.Cipher import AES
from Crypto import Random
import os
import random
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Observação:
# Para este exemplo simplificou-se a geração/armazenamento de keys/passwords pois
# o objetivo principal era explorar ataques especificos e por isso esta parte foi "simplificada"

def generate_MAC(crypt):
    key = b'damqmxtcpujxdhixilcykwyaqcgfyavc'
    h = hmac.HMAC(key, hashes.SHA256(), backend=default_backend())
    h.update(crypt)
    return h.finalize()

def cifrarDet(mensagem):
    key = '6787847643212765'
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.encrypt(mensagem)

def cifrarECB(mensagem):
    key = '3457875643212467'
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.encrypt(mensagem)

def cifrar_nao_deterministico(mensagem):
    key=b'hwbbsssbkmyruiuznuipyapwggpzdfio'
    nonce = os.urandom(16)
    algorithm = algorithms.ChaCha20(key, nonce)
    cipher = Cipher(algorithm, mode=None, backend=default_backend())
    encryptor = cipher.encryptor()
    crypt = encryptor.update(bytes(mensagem,'utf-8'))
    return crypt+nonce

def cifrar_ENC_e_MAC(mensagem):
    cript = cifrar_nao_deterministico(mensagem)
    mac = generate_MAC(bytes(mensagem,'utf-8'))
    res= mac + cript
    return res
    
# Atacante que explora o facto do ECB gerar os blocos da mesma
# maneira pela mesma ordem da mensagem

class AtacanteEcb:
    def __init__(self):
        self.random=""
        self.simetric=""

    def calculaMsgs(self):
        self.random = "Lorem ipsum dolor sit amet amet."
        self.simetric ="abcdefghijklmnop" + "abcdefghijklmnop"
        return self.random,self.simetric

    def escolheMsg(self,criptograma):
        cpm = criptograma[:16]
        cpm2 = criptograma[16:]

        if cpm == cpm2:
            
            return self.simetric
        else:
            return self.random

#Atacante que aproveita o facto das cifras serem "estaticas"

class AtacanteDeterministico:
    def __init__(self,func):
        self.random=""
        self.random2=""
        self.cifrar=func
    def calculaMsgs(self):
        self.random = "Lorem ipsum dolor sit amet amet."
        self.random2 ="BI7ny6JqnGT1hUUnAOIiDN8SRBCyjIdw"
        return self.random,self.random2

    def escolheMsg(self,criptograma):
        cifrar1= self.cifrar(self.random)
        cifrar2= self.cifrar(self.random2)
        if (cifrar1 == criptograma):
            return self.random
        else:
            return self.random2

#Atacante que aproveita o facto de se utilizar um MAC deterministico - ENCRYPT AND MAC
# (cifra aqui é não-deterministica)
class Atancante_Encrypt_And_Mac:
    def __init__(self,func):
        self.random=""
        self.random2=""
        self.cifrar=func

    def calculaMsgs(self):
        self.random = "Secret mensage from USA-DEF army"
        self.random2 ="Cordenates of missiles of DNK KH"
        return self.random,self.random2
    
    def escolheMsg(self,criptograma):
        res = self.cifrar(self.random)
        macRandom = res[:32]
        macCriptograma = criptograma[:32]

        if (macRandom == macCriptograma):
            return self.random
        else:
            return self.random2



#JOGO PARA ATACAR O ECB (USANDO O AES)
def indcpa1():
    a1=AtacanteEcb()
    msgs=a1.calculaMsgs()
    aleatorio = random.getrandbits(1)
    criptograma=cifrarECB(msgs[aleatorio])
    msg_atacante=a1.escolheMsg(criptograma)

    if msg_atacante == msgs[aleatorio]:
            return 1
            #print("Parabéns ganhou o jogo IND-CPA ECB!")
    else:
            #print("Perdeu o jogo IND-CPA ECB !")
            return 0

#JOGO PARA ATACAR TODAS AS CIFRAS DETERMINISTICAS
def indcpa2():
    a1=AtacanteDeterministico(cifrarDet)
    msgs=a1.calculaMsgs()
    aleatorio = random.getrandbits(1)
    criptograma=cifrarDet(msgs[aleatorio])
    msg_atacante=a1.escolheMsg(criptograma)

    if msg_atacante == msgs[aleatorio]:
            return 1
            #print("Parabéns ganhou o jogo indcpa DET!")
    else:
            #print("Perdeu o jogo! indcpa DET")
            return 0

#JOGO PARA ATACAR O MÉTODO ENCRYPT AND MAC
def indcpa3():
    a1=Atancante_Encrypt_And_Mac(cifrar_ENC_e_MAC)
    msgs=a1.calculaMsgs()
    aleatorio = random.getrandbits(1)
    criptograma=cifrar_ENC_e_MAC(msgs[aleatorio])
    msg_atacante=a1.escolheMsg(criptograma)

    if msg_atacante == msgs[aleatorio]:
            return 1
            #print("Parabéns ganhou o jogo indcpa Encryp and Mac!")
    else:
            #print("Perdeu o jogo indcpa Encrypt and Mac!")
            return 0



#CORRER OS JOGOS e analisar os resultados
c1=0
c2=0
c3=0
iteracoes=100
for x in range(iteracoes):
    r1= indcpa1()
    r2= indcpa2()
    r3= indcpa3()
    if (r1==1): c1=c1+1
    if (r2==1): c2=c2+1
    if (r3==1): c3=c3+1   

print('#################################################')
print('# Número de jogos efetuados:                ' + str(iteracoes)+ ' #\n' + '#                                               #')
print('# Vitórias no jogo indCPA ECB:              ' +  str(c1)+ ' #\n' + '#                                               #')
print('# Vitórias no jogo indCPA DET:              ' +  str(c2)+ ' #\n' + '#                                               #')
print('# Vitórias no jogo indCPA Encrypt and Mac:  ' +  str(c3) +' #\n' + '#                                               #')
print('#################################################')