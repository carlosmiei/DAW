var http = require('http')
var fs = require('fs')
var url = require('url')

http.createServer(function(req,res) {

      var myurl = url.parse(req.url,true)
      var caminho  = myurl.pathname
      
      res.writeHead(200,{'Content-Type':'text/html'})

      if (caminho == '/index.html') {

      fs.readFile('website/index.html',(erro,dados)=>{

        if (!erro)
            res.write(dados)
        else
            res.write('<p><b>ERRO</b></p>' + erro)
            res.end()
      })




    } else {

        var caminho = caminho.split("/");
        var doc = caminho[2];
        var uurl = 'website/html/' + doc + '.html'
        fs.readFile(uurl,(erro,dados)=>{

        if (!erro)
            res.write(dados)
         else
            res.write('<p><b>ERRO</b></p>' + erro)
            res.end()
      })


    }


     

}).listen(4004,()=>{console.log('servidor a escuta na porta 4004' )})
