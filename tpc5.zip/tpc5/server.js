var http = require('http')
var fs = require('fs')
var url = require('url')
var pug = require('pug')
var puburl =  /\/pub\//

http.createServer(function(req,res){

    var purl = url.parse(req.url)
    
    if((purl.pathname == '/') || (purl.pathname== '/index')) {
        
        res.writeHead(200,{'Content-Type': 'text/html'})

        fs.readFile('obras-musicais-json/jsonindex2.json',(erro,dados)=>{
            if(!erro) {
                console.log(JSON.parse(dados))
                res.write(pug.renderFile('template/index.pug',{ind:JSON.parse(dados)}))

            } else {
                res.write('<p><b>Erro</b>' + erro + '</p>')
            }
            res.end()
        })
        
    }
    
    else if (puburl.test(purl.pathname)) {
        var ficheiro = purl.pathname.split('/')[2]

        res.writeHead(200,{'Content-Type': 'text/html'})

        fs.readFile('obras-musicais-json/json/' + ficheiro + '.json',(erro,dados)=>{
            if(!erro) {

                res.write(pug.renderFile('template/template.pug',{pub: JSON.parse(dados)}))

            } else {
                res.write('<p><b>Erro</b>' + erro + '</p>')
            }
            res.end()
        })
        

    }
    else if (purl.pathname == '/w3.css') {

        res.writeHead(200,{'Content-Type': 'text/css'})
        fs.readFile('/estilo/w3.css',(erro,dados)=>{
            if(!erro) {

                res.write(dados)

            } else {
                res.write('<p><b>Erro</b>' + erro + '</p>')
            }
        })
       

    }

    else {
        res.writeHead(200,{'Content-Type': 'text/css'})
        res.write('<p><b>Erro URL </b>')
        res.end()
    }


}).listen(5001,()=>{

    console.log('Servidor a escuta na porta 5001...')
})
