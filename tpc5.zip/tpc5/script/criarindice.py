import os, json,codecs,io,operator
from operator import itemgetter
#coding: utf-8

path_to_json = 'obras-musicais-json/json'
json_files = [pos_json for pos_json in os.listdir(path_to_json) if pos_json.endswith('.json')]
data = {}
string = '['

for fich  in json_files:
    with codecs.open('obras-musicais-json/json/'  + fich , 'r','utf-8') as fp:
        try:
            obj = json.load(fp) 
            if json_files.index(fich) != len(json_files)-1:
                string = ''.join([string, '{ \"id\": ' + '\"' + obj['_id'] + '\"' + ',' + '\"title\" :' + '\"' + obj['titulo'] + '\"' + '} ,'])
            else:
                string = ''.join([string, '{ \"id\": ' + '\"' + obj['_id'] + '\"' + ',' + '\"title\" :' + '\"' + obj['titulo'] + '\"' + '} ]'])
                
        except:
            print('Ficheiro invalido '+ fich)
       


d = json.loads(string)
#sorted(d["entries"], key=lambda d: d["title"])
#sorted(d,key=operator.itemgetter('title'),reverse=True)
#sorted(d, key=lambda x: x['title'])
file_json  = codecs.open(path_to_json + 'index2.json', 'w','utf-8')
file_json.write(string)
file_json.close()