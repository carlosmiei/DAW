$(()=>{
    
    $("#upload").click(function (event) {

        event.preventDefault();
       
        ajaxPost()
    })

    function ajaxPost(){
        var form = $('#fileUploadForm')[0];
        var data = new FormData(form);

        $.ajax({
            
            type: "POST",
            enctype: 'multipart/form-data',
            url: "processaForm",
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (data) {
                //alert('correu tudo bem')
                dat = Date(Date.now()).toString()
                res= dat.split('(')
                nome= $('#nome').val()
                console.log('Aqui')
                nome= nome.split('\\')
                $('#tabela').append('<tr> <td>'+'<a href="'+'/fich/'+ nome[2]  +'">'+nome[2]+'</a>'+'</td> <td>'+ $('#desc').val() +'</td>' + '<td>'+ res[0]+'</td>' +  '</tr>')
                //alert('DEPOIS')
                $('#nome').val('')
                $('#desc').val('')

            },
            error: function (e) {
                alert('Problema ao submeter o form!')
            }

        })
        
      
    }
})