var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var formidable = require('formidable')
var myBD= __dirname + '/catalogo.json'
var dirFich = './public/fich/'
var fs =   require('fs')
/* GET home page. */
router.get('/', function(req, res, next) {
  jsonfile.readFile(myBD,(erro,cat)=>{
  
   if (!erro) {
      res.render('index', {catalogo:cat});
   } else {
      res.render('error',{e:erro})
   }
})
});

router.post('/processaForm',(req,res)=>{

  var form = new formidable.IncomingForm()
    form.parse(req,(erro,fields,files)=>{
            var fenviado = files.ficheiro.path
            var fnovo= dirFich + files.ficheiro.name
            fs.rename(fenviado,fnovo,function(err){
                if (!err) {
                    jsonfile.readFile(myBD,(erro,catalogo)=>{
                        data = Date(Date.now()).toString()
                        res= data.split('(')
                        if(!erro){
                            var data = {
                                id: catalogo.length,
                                name: files.ficheiro.name,
                                desc: fields.desc,
                                data: res[0]
                            };
                            catalogo.push(data)
                            jsonfile.writeFile(myBD,catalogo,erro=>{
                                if(erro) console.log(erro)

                                else {
                                    console.log('Registo gravado com sucesso!')
                                }
                            })

                        } else {
                            console.log('Erro no ficheiro ' + erro)
                        }
                    })

                res.writeHead(301,{Location: 'http://localhost:4008/'});
                res.end()
                }else {
                    res.write(pug.renderFile('/pug/erro.pug',{e:'Ocorreram erros na gravação do ficheiro!'}))
                    res.end()
                }

            })
        })
      
  


})

module.exports = router;
